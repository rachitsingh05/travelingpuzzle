---
title: "Finding Quiet in Coimbra, Portugal"
date: 2025-09-17
categories: 
  - Portugal
  - Solo Travel
tags:
  - coimbra
  - europe
  - reflections
layout: single
author_profile: true
---

Nestled in the heart of Portugal, Coimbra surprised me with its ancient libraries, pastel rooftops, and peaceful river walks.

This was a spontaneous detour, but one that made me pause — and piece together a different side of Europe.
