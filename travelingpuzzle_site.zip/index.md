---
layout: home
title: "Welcome to Traveling Puzzle"
excerpt: "Exploring the world one piece at a time — stories, snapshots, and reflections from across the globe."
author_profile: true
---

🌍 Welcome to *Traveling Puzzle*!

Every journey is a puzzle piece. Here, you'll find travel stories, photo journals, and personal reflections from around the world.
