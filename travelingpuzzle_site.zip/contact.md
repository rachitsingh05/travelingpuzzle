---
layout: page
title: Contact
permalink: /contact/
---

Have questions, ideas, or want to collaborate? Drop me a message via [email](mailto:hello@travelingpuzzle.com).
