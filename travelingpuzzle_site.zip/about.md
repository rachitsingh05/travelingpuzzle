---
layout: page
title: About Me
permalink: /about/
---

Hi! I'm the traveler behind *Traveling Puzzle*. This blog is a journal of adventures — short and long — captured in snapshots, emotions, and itineraries.

Think of it like fitting puzzle pieces of cultures, places, and moments from around the world.
